package com.champlain.android.chitchat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdapter: RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {


    var test = arrayOf("test1", "test2", "test3", "test4", "test5")


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerAdapter.ViewHolder{
        val v = LayoutInflater.from(parent.context).inflate(R.layout.recyclerview_row, parent, false)
        return ViewHolder(v)
    }



    override fun getItemCount(): Int {
        return test.size
    }

    override fun onBindViewHolder(holder: RecyclerAdapter.ViewHolder, position: Int) {
        holder.user.text = test[position]
        holder.date.text = test[position]
        holder.likes.text = test[position]
        holder.dislikes.text = test[position]
        holder.message.text = test[position]

    }

    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        var user: TextView
        var date: TextView
        var likes: TextView
        var dislikes: TextView
        var message: TextView

        init{
            user = itemView.findViewById(R.id.user)
            date = itemView.findViewById(R.id.date)
            likes = itemView.findViewById(R.id.likes)
            dislikes = itemView.findViewById(R.id.dislikes)
            message = itemView.findViewById(R.id.message)
        }

    }


}