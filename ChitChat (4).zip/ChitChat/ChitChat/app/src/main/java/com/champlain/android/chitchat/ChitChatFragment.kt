package com.champlain.android.chitchat

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat.recreate
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.champlain.android.chitchat.api.ChitChatApi
import com.champlain.android.chitchat.databinding.FragmentChitChatBinding
import kotlinx.coroutines.launch
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory
import retrofit2.create
import java.io.File


class ChitChatFragment : Fragment() {
    private var _binding: FragmentChitChatBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "Cannot access binding because it is null. Is the view visible?"
        }

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<RecyclerAdapter.ViewHolder>? = null



    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding =
            FragmentChitChatBinding.inflate(inflater, container, false)
        binding.post.layoutManager = GridLayoutManager(context, 1)


        layoutManager = LinearLayoutManager(this.context)
        binding.post.layoutManager = layoutManager

        adapter = RecyclerAdapter()
        binding.post.adapter = adapter



        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        val baseURL = "https://stepoutnyc.com/"

        super.onViewCreated(view, savedInstanceState)
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl(baseURL)
            .addConverterFactory(ScalarsConverterFactory.create())
            .build()

        val chitChatApi: ChitChatApi = retrofit.create<ChitChatApi>()



        var likeButton = view.findViewById<Button>(R.id.like_button)

        likeButton?.setOnClickListener {
            likeButton.isEnabled = false
        }



        viewLifecycleOwner.lifecycleScope.launch {
            //Sends post to server
            //chitChatApi.sendPost("fe6e9938-1d3f-4501-9c12-6e4f678342ba", "andrew.vinci@mymail.champlain.edu","TestingPost3")

            // receives post from server
            val response = chitChatApi.fetchContents()

            Log.d(TAG, "Response received: $response")

            var json = JSONObject(response)
            var messageList = json.getJSONArray("messages")

            var id_list = arrayListOf<String>()
            var client_list = arrayListOf<String>()
            var date_list = arrayListOf<String>()
            var dislikes_list = arrayListOf<Int>()
            var likes_list = arrayListOf<Int>()
            var message_list = arrayListOf<String>()


            for(i in 0..19){

                var jsonObj = messageList.getJSONObject(i)
                val id = jsonObj.optString("_id")
                id_list.add(id)
                val client = jsonObj.optString("client")
                client_list.add(client)
                val date = jsonObj.optString("date")
                date_list.add(date)
                val dislikes = jsonObj.optString("dislikes")
                dislikes_list.add(dislikes.toInt())
                val likes = jsonObj.optString("likes")
                likes_list.add(likes.toInt())
                val message = jsonObj.optString("message")
                message_list.add(message)
            }


            // Create Files to Store Posts
            val messageDirectory = context?.getFilesDir()
            val messageFile = File(messageDirectory, "message.txt")

            val likesDirectory = context?.getFilesDir()
            val likesFile = File(likesDirectory, "likes.txt")

            val dislikesDirectory = context?.getFilesDir()
            val dislikesFile = File(dislikesDirectory, "dislikes.txt")

            val usersDirectory = context?.getFilesDir()
            val usersFile = File(usersDirectory, "users.txt")

            val datesDirectory = context?.getFilesDir()
            val datesFile = File(datesDirectory, "dates.txt")



            // Write to the files with the different data
            messageFile.writeText("")
            for(i in message_list){
                messageFile.appendText(i)
                messageFile.appendText("\n")
            }

            likesFile.writeText("")
            for(i in likes_list){
                likesFile.appendText(i.toString())
                likesFile.appendText("\n")
            }

            dislikesFile.writeText("")
            for(i in dislikes_list){
                dislikesFile.appendText(i.toString())
                dislikesFile.appendText("\n")
            }

            usersFile.writeText("")
            for(i in client_list){
                usersFile.appendText(i)
                usersFile.appendText("\n")
            }

            datesFile.writeText("")
            for(i in date_list){
                datesFile.appendText(i)
                datesFile.appendText("\n")
            }

            Log.d(TAG, "Response received2: $message_list")

        }


    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}