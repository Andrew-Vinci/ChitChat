package com.champlain.android.chitchat.api

import android.provider.ContactsContract.CommonDataKinds.Callable
import android.telecom.Call
import com.champlain.android.chitchat.model.Post
import okhttp3.RequestBody
import okhttp3.Response
import okhttp3.ResponseBody
import okhttp3.internal.http.RealResponseBody
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.http.*
import java.net.ResponseCache


interface ChitChatApi {

    @GET("chitchat?key=fe6e9938-1d3f-4501-9c12-6e4f678342ba&client=andrew.vinci@mymail.champlain.edu")
    suspend fun fetchContents(): String

    @FormUrlEncoded
    @POST("chitchat")
    suspend fun sendPost(@Field("key") key: String, @Field("client") client: String, @Field("message") message: String): ResponseBody

    //@FormUrlEncoded
    /*
    @POST("chitchat?key=fe6e9938-1d3f-4501-9c12-6e4f678342ba&client=andrew.vinci@mymail.champlain.edu&message=")
    suspend fun sendPost(
        //@Field("_id") id: String,
        //@Field("client") client: String,
        //@Field("message") message: String,
        @Query("message") message: String
    ): String
    */


}
