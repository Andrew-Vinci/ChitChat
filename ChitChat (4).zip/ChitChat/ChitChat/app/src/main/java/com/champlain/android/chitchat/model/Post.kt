package com.champlain.android.chitchat.model

import android.widget.Button
import com.champlain.android.chitchat.R

class Post (){





    var id_list = arrayListOf<String>()
    var client_list = arrayListOf<String>()
    var date_list = arrayListOf<String>()
    var dislikes_list = arrayListOf<Int>()
    var likes_list = arrayListOf<Int>()
    var message_list = arrayListOf<String>()

    fun sendData(idArray: ArrayList<String>, clientArray: ArrayList<String>, dateArray: ArrayList<String>, dislikesArray: ArrayList<Int>, likesArray: ArrayList<Int>, messageArray: ArrayList<String>){
        id_list = idArray
        client_list = clientArray
        date_list = dateArray
        dislikes_list = dislikesArray
        likes_list = likesArray
        message_list = messageArray
    }

    fun getID(): ArrayList<String>{
        return id_list
    }

    fun getClients(): ArrayList<String>{
        return client_list
    }

    fun getDates(): ArrayList<String>{
        return date_list
    }

    fun getDislikes(): ArrayList<Int>{
        return dislikes_list
    }

    fun getLikes():ArrayList<Int>{
        return likes_list
    }

    fun getMessages(): ArrayList<String>{
        return message_list
    }




}

