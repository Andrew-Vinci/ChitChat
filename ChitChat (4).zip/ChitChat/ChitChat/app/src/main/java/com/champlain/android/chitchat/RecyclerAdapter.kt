package com.champlain.android.chitchat

import android.content.ContentValues
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.champlain.android.chitchat.model.Post
import java.io.File

class RecyclerAdapter: RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {


    var test = arrayOf("test1", "test2", "test3", "test4", "test5")

    var test2 = 20



    //var test2 = Post().getMessages()




    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerAdapter.ViewHolder{
        val v = LayoutInflater.from(parent.context).inflate(R.layout.recyclerview_row, parent, false)
        return ViewHolder(v)
    }



    override fun getItemCount(): Int {
        return test2
    }

    override fun onBindViewHolder(holder: RecyclerAdapter.ViewHolder, position: Int) {

        //val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)

        var id_list = arrayListOf<String>()
        var client_list = arrayListOf<String>()
        var date_list = arrayListOf<String>()
        var dislikes_list = arrayListOf<Int>()
        var likes_list = arrayListOf<Int>()
        var message_list = arrayListOf<String>()


        // Get the different file paths
        val messageFilePath = "/data/data/com.champlain.android.chitchat/files/message.txt"
        val messageFile = File(messageFilePath)

        val likesFilePath = "/data/data/com.champlain.android.chitchat/files/likes.txt"
        val likesFile = File(likesFilePath)

        val dislikesFilePath = "/data/data/com.champlain.android.chitchat/files/dislikes.txt"
        val dislikesFile = File(dislikesFilePath)

        val usersFilePath = "/data/data/com.champlain.android.chitchat/files/users.txt"
        val usersFile = File(usersFilePath)

        val datesFilePath = "/data/data/com.champlain.android.chitchat/files/dates.txt"
        val datesFile = File(datesFilePath)

        var message = ""
        print(messageFile.name)
        messageFile.bufferedReader().forEachLine {
            message = it
            message_list.add(message)
            println("value = $it")
        }


        // Add the data from the files into the different arrays
        var likes = ""
        print(likesFile.name)
        likesFile.bufferedReader().forEachLine {
            likes = it
            likes_list.add(likes.toInt())
            println("value = $it")
        }

        var dislikes = ""
        print(dislikesFile.name)
        dislikesFile.bufferedReader().forEachLine {
            dislikes = it
            dislikes_list.add(dislikes.toInt())
            println("value = $it")
        }

        var users = ""
        print(usersFile.name)
        usersFile.bufferedReader().forEachLine {
            users = it
            client_list.add(users)
            println("value = $it")
        }

        var dates = ""
        print(datesFile.name)
        datesFile.bufferedReader().forEachLine {
            dates = it
            date_list.add(dates)
            println("value = $it")
        }



        // Add the data from the arrays into recycler view
        holder.user.text =  client_list[position]
        holder.date.text =  date_list[position]
        holder.likes.text = likes_list[position].toString()
        holder.dislikes.text = dislikes_list[position].toString()
        holder.message.text = message_list[position]

    }

    inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        var user: TextView
        var date: TextView
        var likes: TextView
        var dislikes: TextView
        var message: TextView

        init{
            user = itemView.findViewById(R.id.user)
            date = itemView.findViewById(R.id.date)
            likes = itemView.findViewById(R.id.likes)
            dislikes = itemView.findViewById(R.id.dislikes)
            message = itemView.findViewById(R.id.message)
        }

    }


}