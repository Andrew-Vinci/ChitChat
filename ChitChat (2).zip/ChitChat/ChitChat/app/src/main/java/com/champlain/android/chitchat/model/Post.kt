package com.champlain.android.chitchat.model

data class Post (
    //val _id: String,
    //val client: String,
    //val date: String,
   // val dislikes: Int,
   // val ip: String,
    //val likes: Int,
    var message : String
)
